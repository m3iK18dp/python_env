from dagster_shared.serdes.objects.package_entry import (
    ComponentFeatureData as ComponentFeatureData,
    PluginObjectKey as PluginObjectKey,
    PluginObjectSnap as PluginObjectSnap,
    ScaffoldTargetTypeData as ScaffoldTargetTypeData,
)
