__title__ = 'python-socks'
__version__ = '2.7.2'
