from dagster._core.definitions.declarative_automation.legacy.rule_condition import (
    RuleCondition as RuleCondition,
)
