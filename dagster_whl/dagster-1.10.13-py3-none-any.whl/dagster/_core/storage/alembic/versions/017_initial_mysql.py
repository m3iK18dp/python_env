"""initial revision for mysql support.

Revision ID: ba4050312958
Revises: 521d4caca7ad
Create Date: 2021-02-22 23:08:27.392579

"""

# revision identifiers, used by Alembic.
revision = "ba4050312958"
down_revision = "521d4caca7ad"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
