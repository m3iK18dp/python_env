class ArgcompleteException(Exception):
    "Exception raised when the shell argument completion process fails."
