"""
This module is deprecated. Use `prefect.utilities.names` instead.
"""
from prefect.utilities.names import *  # noqa
