from prefect.agent.local.agent import LocalAgent

__all__ = ["LocalAgent"]
