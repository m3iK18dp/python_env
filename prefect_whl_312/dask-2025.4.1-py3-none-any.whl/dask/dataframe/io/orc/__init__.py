from __future__ import annotations

from dask.dataframe.io.orc.core import read_orc, to_orc
